from sadice import SelfAdjDiceLoss
def sadice_loss():
    criterion = SelfAdjDiceLoss()
    return criterion